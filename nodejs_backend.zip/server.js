const express = require("express");
const app = express();
const db = require("./dbConnection/mongoose")
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser"); // or use express.json() if you're using Express 4.16+
const authRoutes = require("./routes/routes"); 
app.use(cors());

app.use(express.json()); 
app.use("/api/auth", authRoutes); 



app.listen(5000, function(){
    console.log("server runing on",5000)
})

const cron = require('node-cron');
const Product = require('./useModel/productModal'); // Import product model
const moment = require('moment-timezone');


cron.schedule('0 0 0 * * *', async () => {
    try {
      const currentDate = moment.tz("Asia/Kolkata").toDate();
      // Delete expired products
      const result = await Product.deleteMany({ expiry_date: { $lt: currentDate } });
  
      console.log(`Deleted ${result.deletedCount} expired products.`);
    } catch (error) {
      console.error("Error deleting expired products:", error);
    }
  }, {
    scheduled: true,
    timezone: "Asia/Kolkata" 
  });
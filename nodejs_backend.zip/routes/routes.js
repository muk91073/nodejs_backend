const express = require("express");
const router = express.Router();
const { signUp ,login,addProduct,productList, updateProductPrice} = require("../apiController/apicontroller"); // Adjust the path to where your controller is located

// Define the POST route for user signup
router.post("/signup", signUp);
router.post("/login", login);
router.post("/addProduct", addProduct);
router.get("/productList", productList);
router.put("/updateProductPrice", updateProductPrice);

module.exports = router;

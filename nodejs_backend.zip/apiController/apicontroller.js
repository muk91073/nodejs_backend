const User = require("../useModel/userModel");
const productModal = require("../useModel/productModal");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

module.exports = {
  signUp: async (req, res) => {
    try {
      const { name, email, password } = req.body;

      //   if (!name || !email || !password) {
      //     return res.status(400).json({ error: "All fields are required" });
      //   }

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ error: "Email already in use" });
      }
      const hashedPassword = await bcrypt.hash(password, 12); // salt rounds = 12
      const newUser = new User({
        name,
        email,
        password: hashedPassword,
      });
      await newUser.save();
      res.status(201).json({
        message: "User created successfully",
        responseCode: 200,
        data: { name: newUser.name, email: newUser.email },
      });
    } catch (error) {
      console.error(error);
      res
        .status(500)
        .json({ error: "Something went wrong, please try again." });
    }
  },

  login: async (req, res) => {
    try {
      let query = {
        $and: [
          { email: req.body.email },
          { staus: { $ne: "DELETE" } },
          // { userType: { $in: ["USER", "ADMIN"] } },
        ],
      };
      let userResult = await User.findOne(query);
      if (!userResult) {
        return res.status(400).json({ error: "User not found" });
      } else {
        console.log(req.body.password);
        console.log(userResult.password);
        bcrypt.compare(
          req.body.password,
          userResult.password,
          (err, isMatch) => {
            if (err) {
              console.log("Error comparing passwords:", err);
              return res.status(500).json({ error: "Something went wrong" });
            }
            if (!isMatch) {
              return res.status(400).json({ error: "Password wrong" });
            }
            const data = { userId: userResult._id, email: userResult.email };
            const token = jwt.sign(data, "test", { expiresIn: "24h" });
            res.status(200).json({
              message: "Login successful",
              responseCode: 200,
              token, // The token is returned directly
              userType: userResult.userType,
              userId: userResult._id,
            });
          }
        );
      }
    } catch (error) {
      console.error(error);
      res
        .status(500)
        .json({ error: "Something went wrong, please try again." });
    }
  },

  addProduct: async (req, res) => {
    try {
      let product_save = await productModal(req.body).save();
      if (!product_save) {
        return res.status(400).json({ error: "Internal server error" });
      } else {
        res.status(200).json({
          message: "Product add successful",
          responseCode: 200,
          product: product_save,
        });
      }
    } catch (error) {
      console.error(error);
      res
        .status(500)
        .json({ error: "Something went wrong, please try again." });
    }
  },

  productList: async (req, res) => {
    try {
      const { product_name } = req.query; // Get the query parameter for filtering
      console.log("search", product_name);

      // Basic query to exclude products marked as 'DELETE'
      let query = {
        $and: [{ status: { $ne: "DELETE" } }],
      };

      // If there's a search term, filter by product_name or category
      if (product_name) {
        query.$and.push({
          $or: [
            { product_name: { $regex: product_name, $options: "i" } }, // Search in product_name field
            { category: { $regex: product_name, $options: "i" } }, // Search in category field
          ],
        });
      }

      // Fetch the results from the database using the query
      const result = await productModal.find(query);

      // If no results, return a 404
      if (!result || result.length === 0) {
        return res
          .status(404)
          .json({ error: "No products found matching your search criteria." });
      }

      // Return the result if products are found
      res.status(200).json({
        message: "Product list fetched successfully",
        responseCode: 200,
        product: result,
      });
    } catch (error) {
      // Log any errors and return a 500 status
      console.error(error);
      res.status(500).json({
        error: "Something went wrong, please try again later.",
      });
    }
  },

  updateProductPrice: async (req, res) => {
    const query = {
      $and: [{ status: { $ne: "DELETE" } }, { _id: req.query._id }],
    };
    const result = await productModal.findOne(query);
    if (!result) {
      return res.status(400).json({ error: "Internal server error" });
    } else {
      const productResult = await productModal.findByIdAndUpdate(
        { _id: result._id },
        {
          $set: {
            price: req.query.price,
          },
        },
        { new: true }
      );
      if (!productResult) {
        return res.status(400).json({ error: "user not found" });
      } else {
        res.status(200).json({
          message: "Product list fetched successfully",
          responseCode: 200,
          product: productResult,
        });
      }
    }
  },


};


const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/mk_productdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoose.connection.on("connected", () => {
    console.log("Successfully connected to the database");
});

mongoose.connection.on("error", (error) => {
    console.log("Error connecting to the database:", error);
});




const userModel = require("../useModel/userModel");
const jwt = require("jsonwebtoken");

module.exports = {
  verifyToken: async (req, res, next) => {
    try {
      if (req.headers.token) {
        let decode = await jwt.verify(req.headers.token, "test");

        if (decode) {
          let userData = await userModel.findOne({ _id: decode.userId });

          if (userData) {
            if (userData.status == "BLOCK") {
              res.send({ responseMessage: "BLOCK" });
            } else if (userData.status == "DELETE") {
              res.send({ responseMessage: "DELETE" });
            } else {
              req.userId = userData._id;
              next();
            }
          }
        } else {
          return res.status(400).json({ error: "jwt not work "});
        }
      }
    } catch (error) {
     console.log(error)
    }
  },
};






const authenticateToken = (req, res, next) => {
    const token = req.header("Authorization")?.replace("Bearer ", "");
  
    if (!token) {
      return res.status(401).json({ error: "Access denied. No token provided." });
    }

    try {
      // Verify token with the secret from the environment variable
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = decoded; // Attach the decoded info (e.g., userId) to the request object
      next();
    } catch (error) {
      return res.status(400).json({ error: "Invalid or expired token." });
    }
  };
  
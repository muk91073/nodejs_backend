const express = require("express");
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
    },
    email: {
      type: String,
    },
    password: {
      type: String,
    },
    userType: {
      type: String,
      enum: ["ADMIN", "USER"],
      default: "USER",
      uppercase: true,
    },
    status: {
      type: String,
      enum: ["Activated", "Deactivated"],
      default: "Activated",
    },
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model("user", userSchema);

module.exports = User;

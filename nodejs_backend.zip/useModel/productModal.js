const express = require("express");
const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
    product_name: {
    type: String,
  },
  image: {
    type: String,
  },
  product_code: {
    type: String,
  },
  price: {
    type: Number,
  },
  category: {
    type: String,
  },
  manufacture_date: {
    type: String,
  },
  expiry_date: {
    type: String,
  },
  owner: {
    type: String,
  },
  status: {
    type: String,
  },
}, {
  timestamps: true, 
});

const Product = mongoose.model("product", productSchema);

module.exports = Product;
